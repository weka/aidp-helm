{{/*
AIDP Observability Helm Chart — Shared Template Helpers
*/}}

{{/*
aidp-observability.fullname — Release name truncated to 63 chars (Kubernetes DNS limit)
Usage: {{ include "aidp-observability.fullname" . }}
*/}}
{{- define "aidp-observability.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
aidp-observability.namespace — Namespace from global.namespace, falls back to .Release.Namespace
Usage: {{ include "aidp-observability.namespace" . }}
*/}}
{{- define "aidp-observability.namespace" -}}
{{- .Values.global.namespace | default .Release.Namespace -}}
{{- end -}}

{{/*
aidp-observability.grafanaNamespace — Namespace where Grafana is installed.
Datasource ConfigMaps must land here so the grafana-sc-datasources sidecar
(which watches only its own namespace unless configured otherwise) picks them up.
Defaults to "monitoring" — override via global.grafanaNamespace in values.yaml.
Usage: {{ include "aidp-observability.grafanaNamespace" . }}
*/}}
{{- define "aidp-observability.grafanaNamespace" -}}
{{- .Values.global.grafanaNamespace | default "monitoring" -}}
{{- end -}}

{{/*
aidp-observability.labels — Standard Kubernetes labels for all AIDP Observability resources
Usage: {{ include "aidp-observability.labels" . }}
*/}}
{{- define "aidp-observability.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aidp-observability
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}

{{/*
aidp-observability.phoenixHostname — derive the Phoenix FQDN from global.cluster.fqdn.
Fails with a descriptive error when global.cluster.fqdn is empty so customers
get a clear message rather than an HTTPRoute with an empty hostname.
Used by 37-04 phoenix-httproute template.
Usage: {{ include "aidp-observability.phoenixHostname" . }}
*/}}
{{- define "aidp-observability.phoenixHostname" -}}
{{- $fqdn := .Values.global.cluster.fqdn | default "" -}}
{{- if not $fqdn -}}
{{- fail "global.cluster.fqdn is required to derive aidp-observability.phoenixHostname (see helm/aidp-observability/values.yaml `global.cluster.fqdn`)" -}}
{{- end -}}
{{- printf "phoenix.%s" $fqdn -}}
{{- end -}}

{{/*
aidp.prometheusOperatorRelease — release label that the existing App-Store-provisioned
Prometheus Operator selects ServiceMonitor and PrometheusRule CRs by.
Defaults to "kube-prometheus-stack" (confirmed via live cluster probe 2026-05-12).
Customers whose App Store init appstack ships with a different release name
override observability.prometheusOperator.releaseLabel in values.yaml.
Used by phases 38/41/42 ServiceMonitor and PrometheusRule templates.
Usage: {{ include "aidp.prometheusOperatorRelease" . }}

MIRROR of helm/aidp/templates/_helpers.tpl:334-345 — keep both in sync.
Phase 38 mirrors this because Helm helpers are chart-scoped and
`helm template helm/aidp-observability/` runs standalone in CI (Pitfall 5).
T-RELEASE-LABEL-DRIFT: any change to the upstream helper in helm/aidp/templates/_helpers.tpl
MUST land in the same commit as this mirror (see 38-01-PLAN.md must_haves.truths).
*/}}
{{- define "aidp.prometheusOperatorRelease" -}}
{{- default "kube-prometheus-stack" .Values.observability.prometheusOperator.releaseLabel -}}
{{- end -}}
