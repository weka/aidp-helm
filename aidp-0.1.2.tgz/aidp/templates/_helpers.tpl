{{/*
AIDP Helm Chart — Shared Template Helpers
*/}}

{{/*
aidp.fullname — Release name truncated to 63 chars (Kubernetes DNS limit)
*/}}
{{- define "aidp.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
aidp.namespace — Namespace from global.namespace, falls back to .Release.Namespace
Usage: {{ include "aidp.namespace" . }}
*/}}
{{- define "aidp.namespace" -}}
{{- .Values.global.namespace | default .Release.Namespace -}}
{{- end -}}

{{/*
aidp.keycloakNamespace — Namespace where Keycloak is deployed.
Falls back to aidp.namespace when keycloak.namespace is empty (the appstack
flow installs Keycloak in the same namespace as AIDP).
Usage: {{ include "aidp.keycloakNamespace" . }}
*/}}
{{- define "aidp.keycloakNamespace" -}}
{{- .Values.keycloak.namespace | default (include "aidp.namespace" .) -}}
{{- end -}}

{{/*
aidp.imageRegistry — Image registry prefix (with trailing /) when set, empty string otherwise
Usage: {{ include "aidp.imageRegistry" . }}
*/}}
{{- define "aidp.imageRegistry" -}}
{{- if .Values.global.imageRegistry -}}
{{- printf "%s/" .Values.global.imageRegistry -}}
{{- end -}}
{{- end -}}

{{/*
aidp.image — Full image reference: [registry/]repository:tag
Accepts a dict with .repository and .tag fields.
Usage: {{ include "aidp.image" (dict "repository" .Values.gui.image.repository "tag" .Values.gui.image.tag "context" .) }}

Note: Pass context as .context so imageRegistry can access .Values.global.imageRegistry
*/}}
{{- define "aidp.image" -}}
{{- $registry := "" -}}
{{- if .context -}}
{{- if .context.Values.global.imageRegistry -}}
{{- $registry = printf "%s/" .context.Values.global.imageRegistry -}}
{{- end -}}
{{- end -}}
{{- printf "%s%s:%s" $registry .repository .tag -}}
{{- end -}}

{{/*
aidp.labels — Standard Kubernetes labels for all AIDP resources
Usage: {{ include "aidp.labels" . }}
*/}}
{{- define "aidp.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aidp
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}

{{/*
aidp.selectorLabels — Selector labels for a named component
Usage: {{ include "aidp.selectorLabels" (dict "app" "aidp-gui") }}
*/}}
{{- define "aidp.selectorLabels" -}}
app: {{ .app }}
{{- end -}}

{{/*
aidp.requiredValue — Belt-and-suspenders required value check (secondary to values.schema.json)
Fails with a descriptive message if value is empty.
Usage: {{ include "aidp.requiredValue" .Values.operator.weka.host | quote }}
*/}}
{{- define "aidp.requiredValue" -}}
{{- if not . -}}
{{- fail "Required value is empty — see values.yaml comments and pre-install checklist in NOTES.txt" -}}
{{- end -}}
{{- . -}}
{{- end -}}
