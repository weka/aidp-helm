{{/*
AIDP Helm Chart — Shared Template Helpers
*/}}

{{/*
aidp.fullname — Release name truncated to 63 chars (Kubernetes DNS limit)
*/}}
{{- define "aidp.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
aidp.namespace — Namespace from global.namespace, falls back to .Release.Namespace
Usage: {{ include "aidp.namespace" . }}
*/}}
{{- define "aidp.namespace" -}}
{{- .Values.global.namespace | default .Release.Namespace -}}
{{- end -}}

{{/*
aidp.keycloakNamespace — Namespace where Keycloak is deployed.
Falls back to aidp.namespace when keycloak.namespace is empty (the appstack
flow installs Keycloak in the same namespace as AIDP).
Usage: {{ include "aidp.keycloakNamespace" . }}
*/}}
{{- define "aidp.keycloakNamespace" -}}
{{- .Values.keycloak.namespace | default (include "aidp.namespace" .) -}}
{{- end -}}

{{/*
aidp.imageRegistry — Image registry prefix (with trailing /) when set, empty string otherwise
Usage: {{ include "aidp.imageRegistry" . }}
*/}}
{{- define "aidp.imageRegistry" -}}
{{- if .Values.global.imageRegistry -}}
{{- printf "%s/" .Values.global.imageRegistry -}}
{{- end -}}
{{- end -}}

{{/*
aidp.image — Full image reference: [registry/]repository:tag
Accepts a dict with .repository and .tag fields.
Usage: {{ include "aidp.image" (dict "repository" .Values.gui.image.repository "tag" .Values.gui.image.tag "context" .) }}

Note: Pass context as .context so imageRegistry can access .Values.global.imageRegistry
*/}}
{{- define "aidp.image" -}}
{{- $registry := "" -}}
{{- if .context -}}
{{- if .context.Values.global.imageRegistry -}}
{{- $registry = printf "%s/" .context.Values.global.imageRegistry -}}
{{- end -}}
{{- end -}}
{{- printf "%s%s:%s" $registry .repository .tag -}}
{{- end -}}

{{/*
aidp.labels — Standard Kubernetes labels for all AIDP resources
Usage: {{ include "aidp.labels" . }}
*/}}
{{- define "aidp.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aidp
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}

{{/*
aidp.selectorLabels — Selector labels for a named component
Usage: {{ include "aidp.selectorLabels" (dict "app" "aidp-gui") }}
*/}}
{{- define "aidp.selectorLabels" -}}
app: {{ .app }}
{{- end -}}

{{/*
aidp.requiredValue — Belt-and-suspenders required value check (secondary to values.schema.json)
Fails with a descriptive message if value is empty.
Usage: {{ include "aidp.requiredValue" .Values.operator.weka.host | quote }}
*/}}
{{- define "aidp.requiredValue" -}}
{{- if not . -}}
{{- fail "Required value is empty — see values.yaml comments and pre-install checklist in NOTES.txt" -}}
{{- end -}}
{{- . -}}
{{- end -}}

{{/*
aidp.deriveHostname — strip a scheme prefix from a URL to produce a bare FQDN.
Strips an optional `http://` or `https://` prefix and a trailing slash.
Returns the input unchanged if no scheme is present (already a bare FQDN).
Usage: {{ include "aidp.deriveHostname" .Values.gui.baseUrl }}
*/}}
{{- define "aidp.deriveHostname" -}}
{{- $raw := . | toString -}}
{{- $noScheme := $raw | trimPrefix "https://" | trimPrefix "http://" -}}
{{- $noTrail := $noScheme | trimSuffix "/" -}}
{{- $noTrail -}}
{{- end -}}

{{/*
aidp.guiHostname — derive the bare GUI FQDN from gui.baseUrl.
Used by the AIDP GUI HTTPRoute hostnames field. Replaces the previously
customer-typed `gui.hostname` (removed under CFG-04).
Usage: {{ include "aidp.guiHostname" . }}
*/}}
{{- define "aidp.guiHostname" -}}
{{- if not .Values.gui.baseUrl -}}
{{- fail "gui.baseUrl is required when gui.enabled is true (no value to derive aidp.guiHostname from)" -}}
{{- end -}}
{{- include "aidp.deriveHostname" .Values.gui.baseUrl -}}
{{- end -}}

{{/*
aidp.keycloakHostname — return global.keycloak.fqdn (bare FQDN).
Used by HTTPRoute hostnames field and hostAlias hostname. Identical to
global.keycloak.fqdn — the helper exists so consumers funnel through one name.
Usage: {{ include "aidp.keycloakHostname" . }}
*/}}
{{- define "aidp.keycloakHostname" -}}
{{- $fqdn := .Values.global.keycloak.fqdn | default "" -}}
{{- if not $fqdn -}}
{{- fail "global.keycloak.fqdn is required (see helm/aidp/values.yaml `global.keycloak.fqdn`)" -}}
{{- end -}}
{{- $fqdn -}}
{{- end -}}

{{/*
aidp.keycloakIssuer — compose the Keycloak OIDC issuer URL from global.keycloak.*
Format: "{scheme}://{fqdn}{basePath}/realms/{realm}"
The `gui.keycloak.issuer` and `ragGateway.keycloak.issuer` legacy fields, if
non-empty, override the derived value to preserve out-of-appstack overrides.
Usage: {{ include "aidp.keycloakIssuer" . }}
*/}}
{{- define "aidp.keycloakIssuer" -}}
{{- $scheme := .Values.global.keycloak.scheme | default "http" -}}
{{- $fqdn := .Values.global.keycloak.fqdn | default "" -}}
{{- if not $fqdn -}}
{{- fail "global.keycloak.fqdn is required to derive aidp.keycloakIssuer" -}}
{{- end -}}
{{- $basePath := .Values.global.keycloak.basePath | default "/auth" -}}
{{- $realm := .Values.global.keycloak.realm | default "rag-gateway" -}}
{{- printf "%s://%s%s/realms/%s" $scheme $fqdn $basePath $realm -}}
{{- end -}}

{{/*
aidp.guiKeycloakIssuer — gui.keycloak.issuer override OR derived issuer.
Lets a standalone-install customer pin gui.keycloak.issuer while the
appstack path leaves it empty and derives.
Usage: {{ include "aidp.guiKeycloakIssuer" . }}
*/}}
{{- define "aidp.guiKeycloakIssuer" -}}
{{- if .Values.gui.keycloak.issuer -}}
{{- .Values.gui.keycloak.issuer -}}
{{- else -}}
{{- include "aidp.keycloakIssuer" . -}}
{{- end -}}
{{- end -}}

{{/*
aidp.ragGatewayKeycloakIssuer — ragGateway.keycloak.issuer override OR derived.
Usage: {{ include "aidp.ragGatewayKeycloakIssuer" . }}
*/}}
{{- define "aidp.ragGatewayKeycloakIssuer" -}}
{{- if .Values.ragGateway.keycloak.issuer -}}
{{- .Values.ragGateway.keycloak.issuer -}}
{{- else -}}
{{- include "aidp.keycloakIssuer" . -}}
{{- end -}}
{{- end -}}

{{/*
aidp.keycloakJwksUrl — derive the OIDC JWKS URL: issuer + "/protocol/openid-connect/certs"
Usage: {{ include "aidp.keycloakJwksUrl" . }}
*/}}
{{- define "aidp.keycloakJwksUrl" -}}
{{- if .Values.ragGateway.keycloak.jwksUrl -}}
{{- .Values.ragGateway.keycloak.jwksUrl -}}
{{- else -}}
{{- printf "%s/protocol/openid-connect/certs" (include "aidp.keycloakIssuer" .) -}}
{{- end -}}
{{- end -}}

{{/*
aidp.keycloakBaseUrl — "{scheme}://{fqdn}" (no realm, no basePath).
Used by rag-bridge to call Keycloak Admin API. Healing the audit §1.1 row 6
http/https drift — base-url and issuer now share the same scheme.
Usage: {{ include "aidp.keycloakBaseUrl" . }}
*/}}
{{- define "aidp.keycloakBaseUrl" -}}
{{- if .Values.ragBridge.keycloak.baseUrl -}}
{{- .Values.ragBridge.keycloak.baseUrl -}}
{{- else -}}
{{- $scheme := .Values.global.keycloak.scheme | default "http" -}}
{{- $fqdn := .Values.global.keycloak.fqdn | default "" -}}
{{- if not $fqdn -}}
{{- fail "global.keycloak.fqdn is required to derive aidp.keycloakBaseUrl" -}}
{{- end -}}
{{- printf "%s://%s" $scheme $fqdn -}}
{{- end -}}
{{- end -}}

{{/*
aidp.keycloakRealm — return global.keycloak.realm (override-able via ragBridge.keycloak.realm).
Usage: {{ include "aidp.keycloakRealm" . }}
*/}}
{{- define "aidp.keycloakRealm" -}}
{{- if .Values.ragBridge.keycloak.realm -}}
{{- .Values.ragBridge.keycloak.realm -}}
{{- else -}}
{{- .Values.global.keycloak.realm | default "rag-gateway" -}}
{{- end -}}
{{- end -}}

{{/*
aidp.guiClientId — OIDC client ID for the AIDP GUI.
Falls back to gui.keycloak.clientId if set (legacy override path); otherwise
returns global.keycloak.clients.gui.
Usage: {{ include "aidp.guiClientId" . }}
*/}}
{{- define "aidp.guiClientId" -}}
{{- if .Values.gui.keycloak.clientId -}}
{{- .Values.gui.keycloak.clientId -}}
{{- else -}}
{{- (.Values.global.keycloak.clients).gui | default "aidp-gui" -}}
{{- end -}}
{{- end -}}

{{/*
aidp.ragGatewayAudience — OIDC audience for rag-gateway JWT verification.
Falls back to ragGateway.keycloak.audience if set; otherwise returns
global.keycloak.clients.ragGateway.
Usage: {{ include "aidp.ragGatewayAudience" . }}
*/}}
{{- define "aidp.ragGatewayAudience" -}}
{{- if .Values.ragGateway.keycloak.audience -}}
{{- .Values.ragGateway.keycloak.audience -}}
{{- else -}}
{{- (.Values.global.keycloak.clients).ragGateway | default "rag-gateway-1" -}}
{{- end -}}
{{- end -}}

{{/*
aidp.keycloakRouteHostname — KeycloakRoute HTTPRoute hostname.
Falls back to derived global.keycloak.fqdn when keycloakRoute.hostname is empty.
Usage: {{ include "aidp.keycloakRouteHostname" . }}
*/}}
{{- define "aidp.keycloakRouteHostname" -}}
{{- if .Values.keycloakRoute.hostname -}}
{{- .Values.keycloakRoute.hostname -}}
{{- else -}}
{{- include "aidp.keycloakHostname" . -}}
{{- end -}}
{{- end -}}

{{/*
aidp.redisUrl — Redis URL with legacy per-service override fallback.
Accepts a dict {"override": <legacy-field>, "context": .}.
Returns override if non-empty; otherwise returns global.redis.url.
Usage:
  {{ include "aidp.redisUrl" (dict "override" .Values.gui.redis.address "context" .) }}
*/}}
{{- define "aidp.redisUrl" -}}
{{- if .override -}}
{{- .override -}}
{{- else -}}
{{- .context.Values.global.redis.url | default "" -}}
{{- end -}}
{{- end -}}

{{/*
aidp.wekaApiHost — derive the WEKA REST API URL: "http://{host}:{port}"
Used by spaceManager (SM_WEKA_API_HOST) so the customer types the IP once.
Falls back to spaceManager.weka.apiHost when set (legacy override).
Usage: {{ include "aidp.wekaApiHost" . }}
*/}}
{{- define "aidp.wekaApiHost" -}}
{{- if .Values.spaceManager.weka.apiHost -}}
{{- .Values.spaceManager.weka.apiHost -}}
{{- else -}}
{{- $host := .Values.global.weka.host | default "" -}}
{{- if not $host -}}
{{- fail "global.weka.host is required to derive aidp.wekaApiHost" -}}
{{- end -}}
{{- $port := .Values.global.weka.port | default 14000 -}}
{{- printf "http://%s:%v" $host $port -}}
{{- end -}}
{{- end -}}

{{/*
aidp.wekaHost — bare WEKA host (no scheme, no port). Used by the operator's
WATCHER_WEKA_HOST env, which the watcher composes into URLs itself.
Falls back to operator.weka.host when set (legacy override).
Usage: {{ include "aidp.wekaHost" . }}
*/}}
{{- define "aidp.wekaHost" -}}
{{- if .Values.operator.weka.host -}}
{{- .Values.operator.weka.host -}}
{{- else -}}
{{- $host := .Values.global.weka.host | default "" -}}
{{- if not $host -}}
{{- fail "global.weka.host is required to derive aidp.wekaHost" -}}
{{- end -}}
{{- $host -}}
{{- end -}}
{{- end -}}

{{/*
aidp.wekaPort — WEKA REST API port. Falls back to operator.weka.port, then
global.weka.port, then 14000.
Usage: {{ include "aidp.wekaPort" . }}
*/}}
{{- define "aidp.wekaPort" -}}
{{- if .Values.operator.weka.port -}}
{{- .Values.operator.weka.port -}}
{{- else -}}
{{- .Values.global.weka.port | default 14000 -}}
{{- end -}}
{{- end -}}

{{/*
aidp.ingestorUrl — Ingestor API hostname injected into watcher pods via the
operator's WATCHER_RUNTIME_ENV_MAP (INGESTOR_API_URL). The watcher composes
the URL with the port itself, so DO NOT prepend a scheme here.
Usage: {{ include "aidp.ingestorUrl" . }}
*/}}
{{- define "aidp.ingestorUrl" -}}
{{- if .Values.operator.ingestor.server -}}
{{- .Values.operator.ingestor.server -}}
{{- else -}}
{{- .Values.global.ingestor.url | default "" -}}
{{- end -}}
{{- end -}}
